Phonebook_API database tables
-----------------------------
There are 11 tables in the Phonebook_API sample database.

 1)employees table stores employees data such as employee id, last name, first name, etc. 
   It also has a field named ReportsTo to specify who reports to whom.

 2)customers table stores customers data.

 3)invoices & invoice_items tables: these two tables store invoice data. 
   The invoices table stores invoice header data and the invoice_items table stores 
   the invoice line items data.

 4)artists table stores artists data. It is a simple table that contains only artist id and name.

 5) albums table stores data about a list of tracks. Each album belongs to one artist. 
    However, one artist may have multiple albums.
 6) media_types table stores media types such as MPEG audio file, ACC audio file, etc.

 7) genres table stores music types such as rock, jazz, metal, etc.

 8) tracks table store the data of songs. Each track belongs to one album.

 9) playlists & playlist_track tables: playlists table store data about playlists. 
    Each playlist contains a list of tracks. Each track may belong to multiple playlists. 
    The relationship between the playlists table and tracks table is many-to-many. 
    The playlist_track table is used to reflect this relationship.


